%% calculate parameters of price response function in linear condition
clc
clear
Tarrif = readmatrix('Tariffs_all.csv', 'OutputType', 'string');
Tarrif(1,:)=[];
load array_A.mat
load linearA.mat

c1=find(Tarrif(:,2)=="Low");
c2=find(Tarrif(:,2)=="High");
c=[c1;c2];

fit_low(:,4)=fit(1:1660,:);
low(:,:)=predict_out(1:1660,:);
fit_high(:,4)=fit(1661:2448,:);
high(:,:)=predict_out(1661:2448,:);
fit_low(:,1:3)=array_ave_Tou_2013(c1,1:3);
fit_high(:,1:3)=array_ave_Tou_2013(c2,1:3);
fit(:,2:4)=array_ave_Tou_2013(c,1:3);

k=0;
for i=1:48

    b_normal=find(k==fit(:,4));
    ave_normal(i,1)=mean(fit(b_normal,1));
    min_normal(i,1)=min(fit(b_normal,1));
    max_normal(i,1)=max(fit(b_normal,1));


    b_low=find(k==fit_low(:,3));
    ave_low(i,1)=mean(low(b_low,4));
    max_low(i,1)=max(low(b_low,4));

    deta_low_normal(i,1)=max_low(i)-ave_normal(i);

    b_high=find(k==fit_high(:,3));
    ave_high(i,1)=mean(high(b_high,4));

    min_high(i,1)=min(high(b_high,4));
    deta_high_normal(i,1)=ave_normal(i)-min_high(i);
    k=k+0.5;
end

deta_low_normal=deta_low_normal./(0.1176-0.0399);
deta_high_normal=deta_high_normal./(0.667-0.1176);

deta_low_normalA=deta_low_normal;
deta_high_normalA=deta_high_normal;
ave_normalA=ave_normal;

save slopA.mat deta_low_normalA deta_high_normalA ave_normalA