%% train SVM model
clc
clear
tic
load trainA.mat

num_size = 0.7;                              % ratio of trainning and testing set
num_samples = length(input);                  % sample number
num_train_s = round(num_size * num_samples); % trainning set

train_x = input(1:num_train_s, 2:4)';
train_y = output(1:num_train_s, 4);
M = size(train_x, 2);

test_x = input(num_train_s + 1: end,2: 4)';
test_y = output(num_train_s + 1: end, 4);
N = size(test_x, 2);

%% Standardlization

[train_x,PS]=mapminmax(train_x,0,1);

%% trainning
train_x=train_x';
rng default  % For reproducibility
Mdl = fitrsvm(train_x,train_y,'KernelFunction','gaussian','KernelScale','auto');
conv = Mdl.ConvergenceInfo.Converged
iter = Mdl.NumIterations

%% testing

[test_x]=mapminmax('apply',test_x,PS);
test_x=test_x';

Y_test_new=predict(Mdl,test_x);
Y_loss=Y_test_new-test_y;

rmse = sqrt(mean((Y_test_new-test_y).^2))
mape = mean(abs((test_y - Y_test_new)./test_y))*100


toc
%% predicting
pred_x=predict_in(:,2:4);
pred_x=pred_x';
[pred_x_std]=mapminmax('apply',pred_x,PS);
pred_x_std=pred_x_std';
fit = predict(Mdl,pred_x_std);
save fitA.mat fit
save linearA.mat
%% plot figure
plot(test_y(1:500))
hold on
plot(Y_test_new(1:500))
legend('Truth','Predicted'),xlabel('Time'),ylabel('Energy consumption (kW)')
