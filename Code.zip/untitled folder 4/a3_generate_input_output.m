%% generate input and output dataset
clc
clear
%% sort dataset according to time (month, day, hour)
load data_preA.mat
load array_A.mat
ave_nonTou_2012=sortrows(ave_nonTou_2012,1,"ascend");
ave_nonTou_2013=sortrows(ave_nonTou_2013,1,"ascend");
ave_Tou_2012=sortrows(ave_Tou_2012,1,"ascend");
ave_Tou_2013=sortrows(ave_Tou_2013,1,"ascend");

%% generate input output
Tarrif = readmatrix('Tariffs_all.csv', 'OutputType', 'string');
b=find(Tarrif(:,2)=='Normal');
input=[array_ave_nonTou_2012(8737:17568,:);array_ave_nonTou_2013(b-1,:)];
output=[array_ave_Tou_2012(8737:17568,:);array_ave_Tou_2013(b-1,:)];

c1=find(Tarrif(:,2)=="Low");
c2=find(Tarrif(:,2)=="High");
c=[c1;c2];
predict_in=[array_ave_nonTou_2013(c-1,:)];
predict_out=array_ave_Tou_2013(c-1,:);
save trainA.mat input output predict_in predict_out


