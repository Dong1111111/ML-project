%% calculate nonlinear price response functino by fitting method
clc
clear
load fitA.mat
load array_A.mat
Tarrif = readmatrix('Tariffs_all.csv', 'OutputType', 'string');
Tarrif(1,:)=[];
%% get the demand change in low and high tariff
c1=find(Tarrif(:,2)=="Low");
c2=find(Tarrif(:,2)=="High");
c=[c1;c2];

fit_low(:,4)=fit(1:1660,:);
fit_high(:,4)=fit(1661:2448,:);
fit_low(:,1:3)=array_ave_Tou_2013(c1,1:3);
fit_high(:,1:3)=array_ave_Tou_2013(c2,1:3);
fit(:,2:4)=array_ave_Tou_2013(c,1:3);

low_price_interval=0.1176-0.0399;
high_price_interval=0.667-0.1176;
%% calculate assumed differentiate tariff
k=0;
for i=1:48

    b_high=find(k==fit_high(:,3));
    b_low=find(k==fit_low(:,3));
    low_hour=fit_low(b_low,4);
    high_hour=fit_high(b_high,4);

    low_hour=sortrows(low_hour,'descend');
    high_hour=sortrows(high_hour,'descend');
    price_int_low=low_price_interval/length(low_hour);
    price_int_high=high_price_interval/length(high_hour);

    low_price(1)=0.0399;
    high_price(1)=0.1176;
    for j=2:length(low_hour)
        low_price(j)=low_price(j-1)+price_int_low;%calcualte prices in low-to-normal price interval
    end
    for j=2:length(high_hour)
        high_price(j)=high_price(j-1)+price_int_high;
    end
    k=k+0.5;
    [function_low(i,:),~,mu_low(i,:)] = polyfit(low_price, low_hour, 4);
    [function_high(i,:),~,mu_high(i,:)]=polyfit(high_price,high_hour,4);
    %% plot the fitting figure
%     figure
%     f = polyval(function_low(i,:),low_price,[],mu_low(i,:));
%     plot(low_price,low_hour,'o')
%     hold on
%     plot(low_price,f)
%     hold off
%     legend('y','f')

    low_price=[];
    high_price=[];
end

save slopA-nonlinear.mat function_low function_high mu_high mu_low