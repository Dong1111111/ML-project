%% calculate average demand of all consumers in 365*48 hours
clc
clear
tic
nonTou_2012 = readmatrix('nonToU2012-A.csv', 'OutputType', 'string');
dTou_2012=readmatrix('dToU2012-A.csv', 'OutputType', 'string');
dTou_2013=readmatrix('dToU2013-A.csv', 'OutputType', 'string');
nonTou_2013 = readmatrix('nonToU2013-A.csv', 'OutputType', 'string');

%% calculate average demand of all consumers in each hour

k=1;
ave_nonTou_2012=string([]);
for i=2:length(nonTou_2012)
    a=any(ave_nonTou_2012==nonTou_2012(i,3));
    if ~a
        str11=char(nonTou_2012(i,3));
        b=find(nonTou_2012(:,3)==nonTou_2012(i,3));
        count=length(b);
        ave_nonTou_2012(k,2)=sum(double(nonTou_2012(b,4)))/count;
        ave_nonTou_2012(k,1)=nonTou_2012(i,3);
        k=k+1;
    end
end

k1=1;
ave_Tou_2012=string([]);
for i=2:length(dTou_2012)
    a=any(ave_Tou_2012==dTou_2012(i,3));
    if ~a
        str11=char(dTou_2012(i,3));
        b=find(dTou_2012(:,3)==dTou_2012(i,3));
        count=length(b);
        ave_Tou_2012(k1,2)=sum(double(dTou_2012(b,4)))/count;
        ave_Tou_2012(k1,1)=dTou_2012(i,3);
        k1=k1+1;
    end
end

k2=1;
ave_nonTou_2013=string([]);
for i=2:length(nonTou_2013)
    a=any(ave_nonTou_2013==nonTou_2013(i,3));
    if ~a
        str11=char(nonTou_2013(i,3));
        b=find(nonTou_2013(:,3)==nonTou_2013(i,3));
        count=length(b);
        ave_nonTou_2013(k2,2)=sum(double(nonTou_2013(b,4)))/count;
        ave_nonTou_2013(k2,1)=nonTou_2013(i,3);
        k2=k2+1;
    end
end

k3=1;
ave_Tou_2013=string([]);
for i=2:length(dTou_2013)
    a=any(ave_Tou_2013==dTou_2013(i,3));
    if ~a
        str11=char(dTou_2013(i,3));
        b=find(dTou_2013(:,3)==dTou_2013(i,3));
        count=length(b);
        ave_Tou_2013(k3,2)=sum(double(dTou_2013(b,4)))/count;
        ave_Tou_2013(k3,1)=dTou_2013(i,3);
        k3=k3+1;
    end
end

toc
ave_Tou_2012 = rmmissing(ave_Tou_2012);
ave_nonTou_2012 = rmmissing(ave_nonTou_2012);
ave_nonTou_2012=sortrows(ave_nonTou_2012,1,"ascend");
ave_nonTou_2013=sortrows(ave_nonTou_2013,1,"ascend");
ave_Tou_2012=sortrows(ave_Tou_2012,1,"ascend");
ave_Tou_2013=sortrows(ave_Tou_2013,1,"ascend");

%% convert string to array
% load data_pre.mat
array_ave_nonTou_2012=[];
for i=1:length(ave_nonTou_2012)
    str11=char(ave_nonTou_2012(i,1));
    array_ave_nonTou_2012(i,1)=double(string(str11(6:7)));
    array_ave_nonTou_2012(i,2)=double(string(str11(9:10)));
    array_ave_nonTou_2012(i,3)=double(string(str11(12:13)))+double(string(str11(15:16)))/60;
    array_ave_nonTou_2012(i,4)=double(ave_nonTou_2012(i,2));
end

array_ave_nonTou_2013=[];
for i=1:length(ave_nonTou_2013)
    str11=char(ave_nonTou_2013(i,1));
    array_ave_nonTou_2013(i,1)=double(string(str11(6:7)));
    array_ave_nonTou_2013(i,2)=double(string(str11(9:10)));
    array_ave_nonTou_2013(i,3)=double(string(str11(12:13)))+double(string(str11(15:16)))/60;
    array_ave_nonTou_2013(i,4)=double(ave_nonTou_2013(i,2));
end

array_ave_Tou_2012=[];
for i=1:length(ave_Tou_2012)
    str11=char(ave_Tou_2012(i,1));
    array_ave_Tou_2012(i,1)=double(string(str11(6:7)));
    array_ave_Tou_2012(i,2)=double(string(str11(9:10)));
    array_ave_Tou_2012(i,3)=double(string(str11(12:13)))+double(string(str11(15:16)))/60;
    array_ave_Tou_2012(i,4)=double(ave_Tou_2012(i,2));
end

array_ave_Tou_2013=[];
for i=1:length(ave_Tou_2013)
    str11=char(ave_Tou_2013(i,1));
    array_ave_Tou_2013(i,1)=double(string(str11(6:7)));
    array_ave_Tou_2013(i,2)=double(string(str11(9:10)));
    array_ave_Tou_2013(i,3)=double(string(str11(12:13)))+double(string(str11(15:16)))/60;
    array_ave_Tou_2013(i,4)=double(ave_Tou_2013(i,2));
end

save data_preA.mat ave_Tou_2013 ave_Tou_2012 ave_nonTou_2013 ave_nonTou_2012
save array_A.mat array_ave_Tou_2013 array_ave_Tou_2012 array_ave_nonTou_2013 array_ave_nonTou_2012
